<!doctype html>
<html lang="hu">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo strtoupper($_POST["category"]) . ' - ' . $_POST["type"] . ' - ' . $_POST["room"] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div>
            <h1>Bejelentés</h1>
            <a href="/index.html"> vissza</a>
        </div>

        <div class="row g-4">
            <div class="col-12 col-lg-6">

                <div class="card shadow-sm">
                    <div class="card-header">
                        <strong>Kategória: </strong> <?php echo strtoupper($_POST['category']) ?>
                    </div>
                    <div class="card-body">
                        <div class="mb-2">
                            <span class="badge text-bg-secondary">Leltári Száám: <?php echo $_POST["inventory-number"] ?> </span> <br>
                            <span class="badge text-bg-secondary">Épület: <?php echo $_POST["building"] ?> </span> <br>
                            <span class="badge text-bg-secondary">Szint: <?php echo $_POST["floor"] ?> </span> <br>
                        </div>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-12 col-lg-6">
                        <div class="card shadow-sm">
                            <div class="card-header">
                                <strong>Formázott JSON: </strong>
                            </div>
                            <div class="card-body">
                        <pre>
                            <?php echo json_encode($_POST, JSON_PRETTY_PRINT) | JSON_UNESCAPED_UNICODE ?>
                        </pre>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php echo $_POST["category"]; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>