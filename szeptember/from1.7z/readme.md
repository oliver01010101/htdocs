
#
## URL
### http://192.168.1.80/submit.php?name=John

- http/https/ftp - protocoll
- :// - elválasztó kötelező
- 192.168.1.80 - host
- :80/:8888/:(port) - :80 az alap ez rejtett a többi látható a linkben
  - 80 - http
  - 443 - https
  - 8000, 9000, 8080, 8888, 9999
- /path/to/file.text - erőforrás, file, mappákban lévő file
- ? 
- name=John - **query string** szöveges információ a backend felé
  - GET
  - key=value&key1=value1

<pre>
<?php

var_dump($_POST);

var_dump($_GET);

var_dump($_SERVER);

?>
</pre>
