<?php
/*
 * Vezérlési szerkezetek
 *      -szekvencia
 *      -szelekció
 *          -if (else if) (else)
 *          -switch
 *          -match
 *      -iteráció
 *          -for
 *          -while
 *          -do while
 *          -foreach
 * */

$errors = [];
$numbers = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input = $_POST["numbers"] ?? '';

    if($input === "" || !is_numeric($input)) {
        $errors[] = "Numbers must be a number";
    }
    else{
        var_dump($input);
        $numbers = (int)$input;
        var_dump($input);
    }

}

?>

<form method="post">
    <label>
        Szám:
        <input type="number" name="numbers"/>
        <button type="submit">Ellenőrzés</button>
    </label>
</form>

<?php
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p style='color: red;'>" . implode("<br>", $error) . "</p>";
        }

    }
    else if($numbers !== null){
        if($numbers % 2 === 0){
            echo "<p><strong>$numbers</strong> páros</p>";
        }
        else if($numbers % 2 !== 0){
            echo "<p><strong>$numbers</strong> páratlan</p>";
        }
    }
?>